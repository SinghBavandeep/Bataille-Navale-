# Bataille Navale

## Etape 1: Affichages.Affichage (*console*)
    - Affichages.Affichage grille 
        - affichage emplacement navires
    - Affichages.Affichage navires

## Etape 2: Mouvement
    - placement navires
    - Sélection navires
    - Mouvement navires
        - w/ dégats reçus
        - w/o dégats reçus

## Etape 3: Dégats
    - Tir navires
        - mod coordonnées
        - mod curseur consol
    - Tir personalisé pour chaque navires
    - affichage dégats navires

## Etape 4: Ordinateur
    - Notion d'intelligence de l' ordinateur
        - aléatoire débile Ok 
        -  aléatoire réduite autour des bateaux du joueurs
        - implémentation de l'IA A* (avec calcul de probabilité)

## Progrès Global

| Etape  | Progrès |
|--------|---------|
| 1      | Fait    |
| 2      | Fait    |
| 3      | Fait    |
| 4      | Bonus   |
| ------ | ------  |
| Fait   | 95 %    |


## Plan d'action

- faire IA